function dismissModal()
{
	$(".modal").modal('hide');
}
